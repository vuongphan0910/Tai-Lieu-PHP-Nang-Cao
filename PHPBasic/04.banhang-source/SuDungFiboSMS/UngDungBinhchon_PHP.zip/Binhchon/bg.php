<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<table width="100%" height="100%" border="0" cellpadding="0" cellspacing="0">
</head>
<script type="text/javascript" src="highslide/highslide.js"></script>
<link href="../css/webviet.css" rel=stylesheet>
<body style="background-image:url(images/2_2.jpg)">
<div align="center">
  <style type="text/css">
* {
    font-family: Verdana, Helvetica;
    font-size: 10pt;
}

body
	{
	scrollbar-face-color: #DCE0E2;
scrollbar-shadow-color: #687888;
scrollbar-highlight-color: #FFFFFF;
scrollbar-3dlight-color: #687888;
scrollbar-darkshadow-color: #DCE0E2;
scrollbar-track-color: #BCBFC0;
scrollbar-arrow-color: #6E7E88;
	font-size: 11px;
	font-family: tahoma, arial, verdana, helvetica, sans-serif;
	text-align: justify;
	color: #FFFFFF;
	background-attachment: fixed;
	background-image: url(images/2_2.jpg);
	background-repeat: no-repeat;
	background-position: left top;
	min-height:40%;
	}
.highslide {
	cursor: url(highslide/graphics/zoomin.cur), pointer;
    outline: none;
}
.highslide-active-anchor img {
	visibility: hidden;
}
.highslide img {
	border: 2px solid gray;
}
.highslide:hover img {
	border: 2px solid black;
}

.highslide-wrapper {
	background: black;
}
.highslide-image {
    border: 2px solid black;
}
.highslide-image-blur {
}
.highslide-caption {
    display: none;
    
    border: 2px solid black;
    border-top: none;
    font-family: Verdana, Helvetica;
    font-size: 10pt;
    padding: 5px;
    background-color: black;
}
.highslide-loading {
    display: block;
	color: black;
	font-size: 8pt;
	font-family: sans-serif;
	font-weight: bold;
    text-decoration: none;
	padding: 2px;
	border: 1px solid black;
    background-color: black;
    
    padding-left: 22px;
    background-image: url(highslide/graphics/loader.black.gif);
    background-repeat: no-repeat;
    background-position: 3px 1px;
}
a.highslide-credits,
a.highslide-credits i {
    padding: 2px;
    color: silver;
    text-decoration: none;
	font-size: 10px;
}
a.highslide-credits:hover,
a.highslide-credits:hover i {
    color: black;
    background-color: gray;
}

.highslide-move {
    cursor: move;
}

.highslide-overlay {
	display: none;
}

a.highslide-full-expand {
	background: url(highslide/graphics/fullexpand.gif) no-repeat;
	display: block;
	margin: 0 10px 10px 0;
	width: 34px;
	height: 34px;
}


/* Controlbar example */
.controlbar {	
	background: url(highslide/graphics/controlbar4.gif);
	width: 167px;
	height: 34px;
}
.controlbar a {	
	display: block;
	float: left;
	/*margin: 0px 0 0 4px;*/	
	height: 27px;
}
.controlbar a:hover {
	background-image: url(highslide/graphics/controlbar4-hover.gif);
}
.controlbar .previous {
	width: 50px;
}
.controlbar .next {
	width: 40px;
	background-position: -50px 0;
}
.controlbar .highslide-move {
	width: 40px;
	background-position: -90px 0;
}
.controlbar .close {
	width: 36px;
	background-position: -130px 0;
}


/* Necessary for functionality */
.highslide-display-block {
    display: block;
}
.highslide-display-none {
    display: none;
}
</style>
  
  
  <script type="text/javascript">

// remove the registerOverlay call to disable the controlbar
hs.registerOverlay({
	thumbnailId: null,
	overlayId: 'controlbar',
	position: 'top right',
	hideOnMouseOut: true
});

hs.graphicsDir = 'highslide/graphics/';
hs.outlineType = 'rounded-black';
// Tell Highslide to use the thumbnail's title for captions
hs.captionEval = 'this.thumb.title';
hs.align='center';

</script>
 
</div>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
  <?php
	require_once("config.php");
	$result = mysql_query("SELECT * FROM begai order by sobinhchon DESC");
	
	while($row = mysql_fetch_array($result))
	{
	?>	  
    <table width="400" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td><?php  echo "<font color='black'><b>Mã số: ".$row['maso']."</b></font>"; ?></td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td><?php  echo "<font color='black'><b>Tên: ".$row['ten']."</b></font><br>"; ?></td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td><?php  echo "<font color='black'><b>Số bình chọn : ".$row['sobinhchon']."</b></font>"; ?></td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td ><?php  echo "<a href=girlxinh/".$row['maso'].".jpg class='highslide' onclick='return hs.expand(this)'><img src='girlxinh/".$row['maso'].".jpg' width='40%' height='40%'></img></a>"; ?><?php  echo "<br/><font color='green'><b>".$row['ghichu']."</b></font>"; ?></td>
    <td align="left" valign="top"></td>
  </tr>
</table>
<br/>
		 
		
<?php
	}
	mysql_close($con);
?>

  </tr>
</table>
<div id="controlbar" class="highslide-overlay controlbar">
	<a href="#" class="previous" onClick="return hs.previous(this)" title="Previous (left arrow key)"></a>
	<a href="#" class="next" onClick="return hs.next(this)" title="Next (right arrow key)"></a>
    <a href="#" class="highslide-move" onClick="return false" title="Click and drag to move"></a>
    <a href="#" class="close" onClick="return hs.close(this)" title="Close"></a>
</div>

</body>
