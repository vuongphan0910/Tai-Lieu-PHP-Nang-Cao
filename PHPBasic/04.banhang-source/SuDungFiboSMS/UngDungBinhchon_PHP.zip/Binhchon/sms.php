<?php

if ($_SERVER['REMOTE_ADDR'] <> "112.78.7.18"){ 
		echo $_SERVER['REMOTE_ADDR']."can not access";
		exit();
	}


$cuphap=strtoupper($_REQUEST['message']);
$phone= $_REQUEST['phone'];
$service=$_REQUEST['service'];
$outb = md5(uniqid(rand(), true));
$tmp=explode(" ",$cuphap);
if($tmp[0]=='FIBO')
{
	//set cu phap
	if(@$tmp[1]=='WEBMASTERCODE') 
	{
		if(@$tmp[2]!=NULL) 
		{
			require_once("config.php");
			$result = mysql_query("SELECT * FROM begai where maso=".@$tmp[2]);
		
			if($row = mysql_fetch_array($result))
			{
				$diem=$row['sobinhchon']+1;
				
				echo '
				<ClientResponse>
					<Message>
						<PhoneNumber>'.$phone.'</PhoneNumber>
						<Message>Em gai '.$row['ten'].' duoc ban binh chon. So diem cua em la '.$diem.'</Message>
						<SMSID> -1</SMSID>
						<ServiceNo>'.$service.'</ServiceNo>
					</Message>
				</ClientResponse>';
	
				$result = mysql_query("update begai set sobinhchon=".$diem." where maso=".@$tmp[2]);
			}
			else
			{
				echo '
				<ClientResponse>
					<Message>
						<PhoneNumber>'.$phone.'</PhoneNumber>
						<Message>Ma so Em gai ban da binh chon khong dung : '.@$tmp[1].'</Message>
						<SMSID> -1</SMSID>
						<ServiceNo>'.$service.'</ServiceNo>
					</Message>
				</ClientResponse>';
				
			}
		}		

	}
}
?>
