<?php

$con = mysql_connect("localhost","root","");
if (!$con)
  {
  die('Co loi xay ra :  ' . mysql_error());
  }

mysql_select_db("testsms", $con);

?>