<?php

 require_once('fibosmsconfig.php');
 CheckRequest();
 
$cuphap=$_REQUEST['message'];
$phone= $_REQUEST['phone'];
$service=$_REQUEST['service'];

/*
$tmp=explode(" ",$cuphap); 
$dapan = $tmp["2"];
mysql_connect("localhost", "", "");
mysql_select_db("");
mysql_query($s1);
*/

echo '<ClientResponse>
         <Message>
              <PhoneNumber>'.$phone.'</PhoneNumber>
              <Message>'.'nguyen van teo'.'</Message>
              <SMSID> -1</SMSID>
              <ServiceNo>'.$service.'</ServiceNo>
           </Message>
       </ClientResponse>';
 ?> 