<?php

function CheckRequest()
{

    $file = "fibosmsserver.txt";
    $fh = fopen($file, "r")or die("can't open fibosmsserver.txt file!");
    $contents = fread($fh, filesize($file));
    fclose($fh);
    $ipList = explode("\n", $contents);
    $serverIP=$_SERVER["REMOTE_ADDR"];
    $ipOK=false;
    for($i=0;$i<count($ipList);$i++)
    {
        //echo $ipList[$i];
        if (trim($serverIP) == trim($ipList[$i]))
            $ipOK=true;
    }
    if ($ipOK == false)
    { 
		
		$file="http://center.fibosms.com/GetServerIP.aspx";
		$fh = fopen($file, "r")or die("can't not connect to FiboSMS server!");
		$contents = fread($fh, 30);
    	fclose($fh);
		if($contents==$serverIP)
		{
			$file = "fibosmsserver.txt";
			$fh = fopen($file, "r+")or die("can't open fibosmsserver.txt file!");
			$contents = $contents."\n".fread($fh, filesize($file));
			fseek($fh, 0);
			 if (fwrite($fh, $contents) == FALSE) 
			 {
				fclose($fh);
				echo "Cannot update server IP !";
				exit;
			}
			fclose($fh);
			return;
		}
		echo $serverIP." can not access";
        exit();
    }
	
}
function AddServerIP($newIP)
{
	CheckRequest();
	$file = "fibosmsserver.txt";
	$fh = fopen($file, "r+")or die("can't open fibosmsserver.txt file!");
	$contents =$newIP."\n".fread($fh, filesize($file));
	fseek($fh, 0);
	 if (fwrite($fh, $contents) == FALSE) 
	 {
		fclose($fh);
		echo "Cannot Add Server IP !";
		exit;
	}
	fclose($fh);
	echo "Add Server IP Done!";
	return;
}
function DeleteServerIP($newIP)
{
	CheckRequest();
	$file = "fibosmsserver.txt";
	$fh = fopen($file, "r+")or die("can't open fibosmsserver.txt file!");
	$contents = fread($fh, filesize($file));
	$contents = str_replace($newIP,"",$contents);
	fseek($fh, 0);
	if (fwrite($fh, $contents) == FALSE) 
	{
		fclose($fh);
		echo "Cannot delete Server IP !";
		exit;
	}
	fclose($fh);
	echo "Delete Server IP Done !";
	return;

}
function ReplaceSpecialCharForXML($strIn)

{

	//$strRet  =  str_replace("""" , "&quot;",$strIn);
	
	$strRet= str_replace("&","&amp;",$strRet);
	
	$strRet= str_replace("'","&apos;",$strRet);
	
	$strRet= str_replace("<","&lt;",$strRet);
	
	$strRet = str_replace(">", "&gt;",$strRet);
	
	return $strRet;

}

function Ecrypt($str)
{
	return $str;
}

function Decrypt($str)
{
	return $str;
}

?> 