<?php
require_once('fibosmsconfig.php');

if(isset($_POST["Q"]))
	$str=$_POST["Q"];
else if( isset($_GET["Q"])&& $_GET["Q"]!="")
	$str=$_GET["Q"];
else
{
	CheckRequest();
	echo ("Connection OK");
	exit;
}

$par = Decode($str);

$pos=strpos($par,"&");
$act=substr($par,3,$pos-3);
$pos=strpos($par,"=",$pos);
$ip=substr($par,$pos+1);
//echo "IP:".$ip."  -  ACT:" .$act;

if($act=="ADD")
{
	AddServerIP($ip);
}
else if($act=="DELL")
{
	DeleteServerIP($ip);
}
else
{
	CheckRequest();
	echo ("Connection OK");
}

function Decode($str)
{
	$trongso=8;
	$kytu="@#%$^&|+-*/\\=~(){}[]<>'`\"?!:;,. _0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
	$kytu_len = strlen($kytu) - 1;
	$code = "";
	$n = strlen($str);
	$i = 0;
	for (;$i<$n;$i++)
	{
		$in = strpos($kytu,$str[$i]) - $trongso;
		
		if ($in < 0)
			$in = $kytu_len - $in + 1;
		
		$code .= $kytu[$in];
	}
	return (String)$code;
}

?>